# TUSHANTH AI

A responsive neon chat website plus a backend that uses an AI model with Tushanth's example-based personality.

## Run it
1. Install Node.js LTS: https://nodejs.org/
2. Open a terminal in this folder and run `npm install`.
3. Set your API key, then run `npm start`.

macOS/Linux:
```bash
export OPENAI_API_KEY="your_api_key_here"
npm start
```
Windows PowerShell:
```powershell
$env:OPENAI_API_KEY="your_api_key_here"
npm start
```
4. Visit http://localhost:3000

Live replies need an API key and API billing/credits; ChatGPT subscriptions and API billing are separate.

## Publish online
Deploy as a Node.js app on a host such as Render or Railway. Build command: `npm install`; start command: `npm start`. Add `OPENAI_API_KEY` in the host's environment-variable settings. Optional: set `OPENAI_MODEL` to a model enabled for your API account.

Never put your API key in `public/index.html` or commit it to a public repository.
